SQLALCHEMY_DATABASE_URI = 'postgresql://vagrant:dbpasswd@localhost/NP'
SQLALCHEMY_ECHO = True
DEBUG = True
